# AI Language Translator

![AI Language Translator Screenshot](assets/HomePage.png)

## 📌 Project Overview
The **AI Language Translator** is a premium, web-based translation application built for the **CodeAlpha Artificial Intelligence Internship**. It provides users with a seamless, highly aesthetic, and responsive interface to translate text between multiple languages instantly. 

The project aims to replicate the premium user experience of modern SaaS applications (like DeepL or ChatGPT) using pure frontend technologies without relying on heavy frameworks.

---

## ✨ Key Features
- **Real-Time Translation**: Powered by a public API (MyMemory API) using the JavaScript `fetch()` method.
- **Modern UI/UX**: Features a Glassmorphism design system with smooth micro-animations.
- **Dark/Light Mode**: Fully functional theme toggler that saves user preferences to `localStorage`.
- **Copy to Clipboard**: Quick 1-click copy buttons for both input and output fields.
- **Custom Toast Notifications**: Auto-dismissing popups for a better user experience (replacing standard browser alerts).
- **Responsive Design**: Works perfectly on Desktop, Tablet, and Mobile devices using Flexbox and CSS Grid.
- **Keyboard Shortcuts**: Supports `Ctrl + Enter` (or `Cmd + Enter`) for lightning-fast translations.

---

## 🛠️ Technologies Used

This project strictly adheres to fundamental web technologies, ensuring lightweight performance and high customizability:

1. **HTML5**: 
   - Uses Semantic HTML (`<main>`, `<section>`, `<nav>`, `<footer>`) for better accessibility and code readability.
2. **CSS3**: 
   - Custom properties (CSS Variables) for theme switching.
   - `backdrop-filter: blur()` used to achieve the frosted glass effect.
   - CSS animations for the gradient background and toast notifications.
3. **Vanilla JavaScript (ES6+)**:
   - DOM Manipulation.
   - Asynchronous programming (`async/await`) for API calls.
   - Built-in Web APIs (`navigator.clipboard` for copying).
4. **FontAwesome CDN**: For scalable vector icons.
5. **Google Fonts**: Uses the 'Inter' font family for a clean, modern typography style.

---

## 📂 Project Structure

The project relies on three core files:

```text
📁 CodeAlpha_LanguageTranslator
 ├── 📄 index.html    # The structure and semantic layout of the application
 ├── 📄 style.css     # All styling, animations, themes, and responsiveness
 └── 📄 script.js     # The logic handling UI events, API calls, and local storage
```

---

## 🧠 Code Logic & Explanation (For Mentors/Teachers)

If reviewing the codebase, here are the key technical highlights:

### 1. The Glassmorphism Effect (CSS)
Instead of flat colors, the UI uses semi-transparent backgrounds with a background blur. This is achieved natively in CSS:
```css
.glass {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(16px);
}
```

### 2. Theme Toggling (JS + CSS)
Theme switching is handled by modifying a `data-theme` attribute on the root HTML element. CSS variables (`:root` and `[data-theme="dark"]`) automatically swap all colors. The preference is stored using `localStorage` so it persists across sessions.

### 3. API Integration (JS)
The core translation logic uses the modern `fetch()` API. The code is written in a modular way so that the API endpoint can easily be swapped for Google Cloud Translation or DeepL in an enterprise environment.
```javascript
const response = await fetch(`https://api.mymemory.translated.net/get?q=${text}&langpair=${source}|${target}`);
const data = await response.json();
```

---

## 🚀 How to Run the Project
Since this is a purely frontend application, there is no need for `npm`, Node.js, or local servers.
1. Download and extract the project files.
2. Open the `index.html` file directly in any modern web browser (Chrome, Firefox, Edge, Safari).
3. The app is ready to run locally in your browser or deploy on a static hosting platform.

---

**Developed by Asmit**  
*CodeAlpha Artificial Intelligence Internship*
