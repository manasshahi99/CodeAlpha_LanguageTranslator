/**
 * AI Language Translator — Premium SaaS Vanilla JS
 */

// ── DOM References ─────────────────────────────────────────
const sourceLangSelect  = document.getElementById('source-lang');
const targetLangSelect  = document.getElementById('target-lang');
const sourceText        = document.getElementById('source-text');
const targetText        = document.getElementById('target-text');
const swapBtn           = document.getElementById('swap-btn');
const translateBtn      = document.getElementById('translate-btn');
const clearBtn          = document.getElementById('clear-btn');
const micBtn            = document.getElementById('mic-btn');
const copyBtns          = document.querySelectorAll('.copy-btn');
const charCount         = document.getElementById('current-chars');
const loadingSpinner    = document.getElementById('loading-spinner');
const translationStatus = document.getElementById('translation-status');
const themeToggle       = document.getElementById('theme-toggle');
const toastContainer    = document.getElementById('toast-container');

// ── Constants ──────────────────────────────────────────────
const MAX_CHARS = 5000;
const API_URL   = 'https://api.mymemory.translated.net/get';

// ── Language List ──────────────────────────────────────────
const languages = {
    "en-GB": "English (UK)",
    "en-US": "English (US)",
    "hi-IN": "Hindi",
    "es-ES": "Spanish",
    "fr-FR": "French",
    "de-DE": "German",
    "it-IT": "Italian",
    "pt-PT": "Portuguese",
    "zh-CN": "Chinese (Simplified)",
    "ja-JP": "Japanese",
    "ko-KR": "Korean",
    "ru-RU": "Russian",
    "ar-SA": "Arabic",
    "bn-IN": "Bengali",
    "tr-TR": "Turkish",
    "nl-NL": "Dutch",
    "pl-PL": "Polish",
    "sv-SE": "Swedish",
    "vi-VN": "Vietnamese",
    "th-TH": "Thai",
    "id-ID": "Indonesian"
};

// ── Init ───────────────────────────────────────────────────
function init() {
    populateLanguageDropdowns();
    setupEventListeners();
    initTheme();
}

// ── Populate Dropdowns ─────────────────────────────────────
function populateLanguageDropdowns() {
    let options = '';
    for (const [code, name] of Object.entries(languages)) {
        options += `<option value="${code}">${name}</option>`;
    }
    sourceLangSelect.innerHTML = `<option value="Autodetect">Auto Detect</option>` + options;
    targetLangSelect.innerHTML = options;
    sourceLangSelect.value = 'Autodetect';
    targetLangSelect.value = 'hi-IN';
}

// ── Event Listeners ────────────────────────────────────────
function setupEventListeners() {
    themeToggle.addEventListener('click', toggleTheme);
    swapBtn.addEventListener('click', swapLanguages);
    sourceText.addEventListener('input', handleTextInput);
    clearBtn.addEventListener('click', clearText);
    translateBtn.addEventListener('click', translateText);
    micBtn.addEventListener('click', toggleMic);

    sourceText.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            translateText();
        }
    });

    copyBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.getAttribute('data-target') + '-text';
            copyToClipboard(document.getElementById(id).value);
        });
    });

    document.querySelectorAll('.speak-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.getAttribute('data-target');
            const text   = document.getElementById(target + '-text').value;
            const lang   = target === 'source' ? sourceLangSelect.value : targetLangSelect.value;
            speakText(text, lang, btn);
        });
    });
}

// ── Theme ──────────────────────────────────────────────────
function initTheme() {
    const saved = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
    updateThemeIcon(saved);
}

function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme');
    const next    = current === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
    updateThemeIcon(next);
}

function updateThemeIcon(theme) {
    themeToggle.querySelector('i').className =
        theme === 'dark' ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
}

// ── Text Input ─────────────────────────────────────────────
function handleTextInput(e) {
    let text = e.target.value;
    if (text.length > MAX_CHARS) {
        text = text.substring(0, MAX_CHARS);
        e.target.value = text;
        showToast('Maximum character limit reached', 'info');
    }
    charCount.textContent = text.length;
}

// ── Clear ──────────────────────────────────────────────────
function clearText() {
    if (activeSpeech) {
        window.speechSynthesis.cancel();
        activeSpeech = null;
        document.querySelectorAll('.speak-btn').forEach(resetSpeakBtn);
    }
    sourceText.value       = '';
    targetText.value       = '';
    charCount.textContent  = '0';
    setStatus('Ready', '');
    targetText.placeholder = 'Translation will appear here...';
}

// ── Swap ───────────────────────────────────────────────────
function swapLanguages() {
    const src = sourceLangSelect.value;
    const tgt = targetLangSelect.value;

    if (src === 'Autodetect') {
        sourceLangSelect.value = tgt;
        targetLangSelect.value = 'en-US';
    } else {
        sourceLangSelect.value = tgt;
        targetLangSelect.value = src;
    }

    const tmp        = sourceText.value;
    sourceText.value = targetText.value;
    targetText.value = tmp;

    charCount.textContent = sourceText.value.length;
    setStatus('Ready', '');
}

// ── Status helper ──────────────────────────────────────────
function setStatus(text, className) {
    translationStatus.textContent = text;
    translationStatus.className   = 'status-text' + (className ? ` ${className}` : '');
}

// ── Proper Noun Protection ─────────────────────────────────
const MATRAS = new Set([
    'ा','ि','ी','ु','ू','े','ै','ो','ौ','ृ','्','ं','ः','ँ','़'
]);

const CON_MAP = {
    'क':'k','ख':'kh','ग':'g','घ':'gh','ङ':'ng',
    'च':'ch','छ':'chh','ज':'j','झ':'jh','ञ':'ny',
    'ट':'t','ठ':'th','ड':'d','ढ':'dh','ण':'n',
    'त':'t','थ':'th','द':'d','ध':'dh','न':'n',
    'प':'p','फ':'ph','ब':'b','भ':'bh','म':'m',
    'य':'y','र':'r','ल':'l','व':'v',
    'श':'sh','ष':'sh','स':'s','ह':'h','ळ':'l'
};

const MATRA_MAP = {
    'ा':'a','ि':'i','ी':'ee','ु':'u','ू':'oo',
    'े':'e','ै':'ai','ो':'o','ौ':'au','ृ':'ri',
    '्':'','ं':'n','ः':'h','ँ':'n','़':''
};

const VOWEL_MAP = {
    'अ':'a','आ':'aa','इ':'i','ई':'ee','उ':'u','ऊ':'oo',
    'ए':'e','ऐ':'ai','ओ':'o','औ':'au','ऋ':'ri',
    'अं':'an','अः':'ah'
};

const CLUSTERS = [
    ['क्ष','ksh'],['त्र','tr'],['ज्ञ','gya'],['श्र','shr'],
    ['द्ध','ddh'],['द्व','dv'],
    ['प्र','pra'],['ब्र','bra'],['क्र','kra'],['ग्र','gra'],
    ['ट्र','tra'],['ड्र','dra'],['फ्र','fra'],['म्र','mra'],
    ['व्र','vra'],['स्र','sra'],['ह्र','hra'],
];

function transliterateDevanagari(word) {
    let s = word;
    for (const [dev, lat] of CLUSTERS) s = s.split(dev).join(lat);

    let result = '';
    const chars = [...s];
    for (let i = 0; i < chars.length; i++) {
        const ch   = chars[i];
        const next = chars[i + 1] || '';
        if (VOWEL_MAP[ch])              result += VOWEL_MAP[ch];
        else if (CON_MAP[ch]) {
            result += CON_MAP[ch];
            if (next && !MATRAS.has(next)) result += 'a';
        }
        else if (MATRA_MAP[ch] !== undefined) result += MATRA_MAP[ch];
        else if (/[a-zA-Z]/.test(ch))   result += ch;
    }
    return result.charAt(0).toUpperCase() + result.slice(1);
}

const GREETING_WORDS = [
    'नमस्ते','हैलो','हाय','प्रिय','डियर',
    'hello','hi','hey','dear','namaste'
];

function protectProperNouns(text) {
    const map = {};
    let idx = 0;
    let result = text;

    result = result.replace(/\b([A-Z][a-zA-Z]{1,})\b/g, (match) => {
        const ph = `XPNX${idx}X`;
        map[ph]  = match;
        idx++;
        return ph;
    });

    const greetRe = new RegExp(
        '(' + GREETING_WORDS.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')' +
        '(\\s+)([\\u0900-\\u097F]+)',
        'gi'
    );

    result = result.replace(greetRe, (match, greeting, space, name) => {
        const romanized = transliterateDevanagari(name);
        const ph = `XPNX${idx}X`;
        map[ph]  = romanized;
        idx++;
        return greeting + space + ph;
    });

    return { protected: result, map };
}

function restoreProperNouns(text, map) {
    let result = text;
    for (const [ph, original] of Object.entries(map)) {
        result = result.split(ph).join(original);
    }
    return result;
}

// ── Typing Animation ───────────────────────────────────────
function revealText(element, text) {
    element.value = '';
    element.classList.remove('output-reveal');
    const words = text.split(' ');
    let built = '', i = 0;
    const step = () => {
        if (i >= words.length) { element.classList.add('output-reveal'); return; }
        built        += (i === 0 ? '' : ' ') + words[i];
        element.value = built;
        i++;
        setTimeout(step, 18);
    };
    step();
}

// ── Translate ──────────────────────────────────────────────
async function translateText() {
    const raw        = sourceText.value.trim();
    const sourceLang = sourceLangSelect.value;
    const targetLang = targetLangSelect.value;

    if (!raw) { showToast('Please enter text to translate', 'error'); return; }
    if (sourceLang !== 'Autodetect' && sourceLang === targetLang) {
        showToast('Source and target languages must be different', 'info');
        return;
    }

    targetText.value       = '';
    targetText.placeholder = 'Translating...';
    loadingSpinner.classList.remove('hidden');
    setStatus('Translating...', 'translating');
    translateBtn.disabled  = true;

    const { protected: safeText, map: nounMap } = protectProperNouns(raw);

    try {
        const response = await fetch(
            `${API_URL}?q=${encodeURIComponent(safeText)}&langpair=${sourceLang}|${targetLang}`
        );
        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const data = await response.json();

        if (data.responseData?.translatedText) {
            const raw_result = data.responseData.translatedText;
            if (raw_result.toLowerCase().includes('mymemory warning'))
                throw new Error('API daily limit reached');

            const finalText = restoreProperNouns(raw_result, nounMap);
            loadingSpinner.classList.add('hidden');
            revealText(targetText, finalText);
            setStatus('Translation complete ✓', 'complete');
            showToast('Translation successful', 'success');
        } else {
            throw new Error('Invalid response format');
        }
    } catch (error) {
        console.error('Translation error:', error);
        loadingSpinner.classList.add('hidden');
        targetText.placeholder = 'Translation failed. Please try again.';
        setStatus('Error occurred', 'error');
        const msg = error.message === 'API daily limit reached'
            ? 'Daily limit reached. Try again tomorrow.'
            : 'Failed to translate. Check your connection.';
        showToast(msg, 'error');
    } finally {
        translateBtn.disabled = false;
    }
}

// ── Copy to Clipboard ──────────────────────────────────────
function copyToClipboard(text) {
    if (!text) { showToast('Nothing to copy', 'info'); return; }
    navigator.clipboard.writeText(text)
        .then(() => showToast('Copied to clipboard!', 'success'))
        .catch(() => showToast('Failed to copy text', 'error'));
}

// ── Text to Speech ─────────────────────────────────────────
let activeSpeech   = null;
let activeSpeakBtn = null;

const SPEECH_LANG_MAP = {
    'en-US':'en-US','en-GB':'en-GB','hi-IN':'hi-IN',
    'es-ES':'es-ES','fr-FR':'fr-FR','de-DE':'de-DE',
    'it-IT':'it-IT','pt-PT':'pt-PT','zh-CN':'zh-CN',
    'ja-JP':'ja-JP','ko-KR':'ko-KR','ru-RU':'ru-RU',
    'ar-SA':'ar-SA','bn-IN':'bn-IN','tr-TR':'tr-TR',
    'nl-NL':'nl-NL','pl-PL':'pl-PL','sv-SE':'sv-SE',
    'vi-VN':'vi-VN','th-TH':'th-TH','id-ID':'id-ID',
    'Autodetect':'en-US'
};

function getBestVoice(bcp47) {
    const voices     = window.speechSynthesis.getVoices();
    if (!voices.length) return null;
    const langPrefix = bcp47.split('-')[0].toLowerCase();
    return voices.find(v => v.lang.toLowerCase() === bcp47.toLowerCase())
        || voices.find(v => v.lang.toLowerCase().startsWith(langPrefix + '-'))
        || voices.find(v => v.lang.toLowerCase() === langPrefix)
        || voices.find(v => v.lang.toLowerCase().startsWith('en'))
        || voices[0] || null;
}

function speakText(text, langCode, btn) {
    if (!text) { showToast('Nothing to speak', 'info'); return; }
    if (!('speechSynthesis' in window)) { showToast('Speech not supported', 'error'); return; }

    if (activeSpeech) {
        window.speechSynthesis.cancel();
        activeSpeech = null;
        if (activeSpeakBtn) resetSpeakBtn(activeSpeakBtn);
        activeSpeakBtn = null;
        return;
    }

    const targetLang = SPEECH_LANG_MAP[langCode] || 'en-US';

    const doSpeak = (retryWithoutVoice = false) => {
        const utterance  = new SpeechSynthesisUtterance(text);
        utterance.rate   = 0.92;
        utterance.pitch  = 1;
        utterance.volume = 1;

        if (!retryWithoutVoice) {
            const voice = getBestVoice(targetLang);
            if (voice) { utterance.voice = voice; utterance.lang = voice.lang; }
            else        { utterance.lang = targetLang; }
        }

        setSpeakingState(btn, true);
        activeSpeech   = utterance;
        activeSpeakBtn = btn;

        utterance.onend = () => {
            activeSpeech = null; activeSpeakBtn = null; resetSpeakBtn(btn);
        };

        utterance.onerror = (e) => {
            activeSpeech = null; activeSpeakBtn = null; resetSpeakBtn(btn);
            if (e.error === 'interrupted' || e.error === 'canceled' || e.error === 'cancelled') return;
            if (!retryWithoutVoice) {
                setTimeout(() => doSpeak(true), 100);
            } else {
                showToast('Speech not available for this language on this device', 'info');
            }
        };

        window.speechSynthesis.speak(utterance);
    };

    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
        doSpeak();
    } else {
        window.speechSynthesis.onvoiceschanged = () => {
            window.speechSynthesis.onvoiceschanged = null;
            doSpeak();
        };
        setTimeout(() => { if (!activeSpeech) doSpeak(); }, 600);
    }
}

function setSpeakingState(btn, speaking) {
    if (!btn) return;
    btn.querySelector('i').className = speaking ? 'fa-solid fa-stop' : 'fa-solid fa-volume-high';
    btn.classList.toggle('speaking', speaking);
}

function resetSpeakBtn(btn) { setSpeakingState(btn, false); }

// ── Speech to Text (Mic) ───────────────────────────────────
let recognition = null;
let isListening = false;

const RECOG_LANG_MAP = {
    'en-US':'en-US','en-GB':'en-GB','hi-IN':'hi-IN',
    'es-ES':'es-ES','fr-FR':'fr-FR','de-DE':'de-DE',
    'it-IT':'it-IT','pt-PT':'pt-PT','zh-CN':'zh-CN',
    'ja-JP':'ja-JP','ko-KR':'ko-KR','ru-RU':'ru-RU',
    'ar-SA':'ar-SA','bn-IN':'bn-IN','tr-TR':'tr-TR',
    'nl-NL':'nl-NL','pl-PL':'pl-PL','sv-SE':'sv-SE',
    'vi-VN':'vi-VN','th-TH':'th-TH','id-ID':'id-ID',
    'Autodetect':'en-US'
};

function toggleMic() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        showToast('Speech recognition not supported. Use Chrome or Edge.', 'info');
        return;
    }

    if (isListening && recognition) { recognition.stop(); return; }

    recognition = new SpeechRecognition();
    recognition.lang            = RECOG_LANG_MAP[sourceLangSelect.value] || 'en-US';
    recognition.interimResults  = true;
    recognition.continuous      = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
        isListening = true;
        micBtn.classList.add('listening');
        micBtn.querySelector('i').className = 'fa-solid fa-microphone-slash';
        showToast('Listening... Speak now', 'info');
    };

    recognition.onresult = (e) => {
        let transcript = '';
        for (let i = e.resultIndex; i < e.results.length; i++) {
            transcript += e.results[i][0].transcript;
        }
        sourceText.value      = transcript;
        charCount.textContent = transcript.length;
    };

    recognition.onend = () => {
        isListening = false;
        micBtn.classList.remove('listening');
        micBtn.querySelector('i').className = 'fa-solid fa-microphone';
    };

    recognition.onerror = (e) => {
        isListening = false;
        micBtn.classList.remove('listening');
        micBtn.querySelector('i').className = 'fa-solid fa-microphone';
        if (e.error === 'not-allowed') {
            showToast('Microphone access denied. Allow mic in browser settings.', 'error');
        } else if (e.error !== 'no-speech' && e.error !== 'aborted') {
            showToast('Mic error: ' + e.error, 'error');
        }
    };

    recognition.start();
}

// ── Toast Notifications ────────────────────────────────────
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', info: 'fa-info-circle' };
    toast.innerHTML = `
        <i class="fa-solid ${icons[type] || icons.info}"></i>
        <span>${message}</span>
    `;
    toastContainer.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('fade-out');
        toast.addEventListener('animationend', () => toast.remove(), { once: true });
    }, 3000);
}

// ── Start ──────────────────────────────────────────────────
init();
