# Optional local assets

The chatbot avatars are drawn with CSS to keep the project lightweight and fully offline with no image downloads. You can place custom bot.png and user.png files in this folder later if you would like to replace the CSS avatars.
