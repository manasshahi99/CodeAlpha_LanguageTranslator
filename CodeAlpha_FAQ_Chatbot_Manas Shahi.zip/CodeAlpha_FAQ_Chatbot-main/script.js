/*
  Main chat interface behavior.
  FAQ_DATA is loaded from faq.js and the matching helper is loaded from utils.js.
*/

const chatArea = document.getElementById("chatArea");
const chatForm = document.getElementById("chatForm");
const questionInput = document.getElementById("questionInput");
const sendButton = document.getElementById("sendButton");
const clearChatButton = document.getElementById("clearChatButton");
const themeButton = document.getElementById("themeButton");
const themeIcon = document.getElementById("themeIcon");
const welcomeCard = document.getElementById("welcomeCard");
const fallbackMessage = "I couldn't find a close match in my local AI knowledge base. Try asking about Artificial Intelligence, Machine Learning, Deep Learning, NLP, Computer Vision, Neural Networks, or Data Science.";
let isWaitingForAnswer = false;

function scrollToLatestMessage() {
  window.setTimeout(function () {
    window.scrollTo({
      top: document.body.scrollHeight,
      behavior: "smooth"
    });
  }, 40);
}

function addUserMessage(question) {
  const template = document.getElementById("userMessageTemplate");
  const message = template.content.cloneNode(true);
  message.querySelector(".message-bubble").textContent = question;
  chatArea.appendChild(message);
}

function addBotMessage(answer, match) {
  const template = document.getElementById("botMessageTemplate");
  const message = template.content.cloneNode(true);
  message.querySelector(".message-bubble").textContent = answer;

  const note = message.querySelector(".match-note");
  if (match && match.faq) {
    note.textContent = "Matched topic: " + match.faq.category;
  } else {
    note.remove();
  }

  chatArea.appendChild(message);
}

function showTypingIndicator() {
  const template = document.getElementById("typingTemplate");
  const indicator = template.content.cloneNode(true);
  chatArea.appendChild(indicator);
  scrollToLatestMessage();
}

function removeTypingIndicator() {
  const indicator = chatArea.querySelector(".typing-row");
  if (indicator) {
    indicator.remove();
  }
}

function setChatBusy(busy) {
  isWaitingForAnswer = busy;
  sendButton.disabled = busy;
  questionInput.disabled = busy;
}

function askQuestion(question) {
  const cleanQuestion = question.trim();

  if (!cleanQuestion || isWaitingForAnswer) {
    return;
  }

  if (welcomeCard) {
    welcomeCard.remove();
  }

  addUserMessage(cleanQuestion);
  questionInput.value = "";
  setChatBusy(true);
  showTypingIndicator();
  scrollToLatestMessage();

  // A short delay makes the chat interaction feel natural.
  window.setTimeout(function () {
    const match = findBestFAQ(cleanQuestion, FAQ_DATA);
    removeTypingIndicator();

    if (match) {
      addBotMessage(match.faq.answer, match);
    } else {
      addBotMessage(fallbackMessage, null);
    }

    setChatBusy(false);
    questionInput.focus();
    scrollToLatestMessage();
  }, 750);
}

chatForm.addEventListener("submit", function (event) {
  event.preventDefault();
  askQuestion(questionInput.value);
});

document.querySelectorAll("[data-question]").forEach(function (button) {
  button.addEventListener("click", function () {
    askQuestion(button.dataset.question);
  });
});

clearChatButton.addEventListener("click", function () {
  if (isWaitingForAnswer) {
    return;
  }

  chatArea.innerHTML = "";
  chatArea.appendChild(welcomeCard);
  questionInput.value = "";
  questionInput.focus();
  window.scrollTo({ top: 0, behavior: "smooth" });
});

themeButton.addEventListener("click", function () {
  document.body.classList.toggle("light-theme");
  const isLightTheme = document.body.classList.contains("light-theme");
  themeIcon.textContent = isLightTheme ? "☾" : "☼";
  themeButton.setAttribute("aria-label", isLightTheme ? "Switch to dark theme" : "Switch to light theme");
});
