# AI FAQ Chatbot

<p align="center">
  <img src="https://img.shields.io/badge/CodeAlpha-AI%20Internship-7C5CFC?style=for-the-badge" alt="CodeAlpha AI Internship">
  <img src="https://img.shields.io/badge/Frontend-HTML%20%7C%20CSS%20%7C%20JavaScript-1B243D?style=for-the-badge" alt="Frontend technologies">
  <img src="https://img.shields.io/badge/Status-Ready%20to%20Deploy-2DD4BF?style=for-the-badge" alt="Ready to deploy">
</p>

<p align="center">
  A polished AI and Machine Learning FAQ chatbot built for the <strong>CodeAlpha Artificial Intelligence Internship</strong>.
  It helps users find clear answers through local FAQ matching in a modern, responsive chat experience.
</p>

---

## ✨ Features

| Feature | Description |
| --- | --- |
| 🧠 AI & ML Knowledge Base | 100+ curated Artificial Intelligence and Machine Learning FAQs. |
| 🔎 Intelligent FAQ Matching | Finds the closest relevant question from the local knowledge base. |
| ✂️ Text Preprocessing | Cleans and prepares user questions before matching. |
| 💬 Modern Chat Interface | Clean conversational UI with suggested questions and avatars. |
| 🌙 Responsive Dark Theme | Comfortable, mobile-friendly design that adapts across screen sizes. |
| ⌨️ Smooth Interactions | Typing animation, auto-scroll, Enter-key support, and clear chat. |
| ⚡ Fast & Lightweight | Runs entirely in the browser with no setup complexity. |
| 🚀 Easy Deployment | Ready for GitHub Pages and Vercel. |

## 🛠️ Technologies Used

- HTML5
- CSS3
- Vanilla JavaScript

## 🧩 NLP Concepts Used

The chatbot uses simple, beginner-friendly Natural Language Processing concepts:

- **Lowercasing:** Treats “AI” and “ai” as the same word.
- **Punctuation removal:** Removes symbols that do not help with matching.
- **Tokenization:** Splits a question into individual words.
- **Stopword removal:** Ignores common words such as “the”, “is”, and “what”.
- **FAQ matching:** Compares meaningful question words with stored FAQs.
- **Similarity-based search:** Selects the FAQ with the strongest keyword overlap.

## 📂 Project Structure

~~~text
CodeAlpha_FAQ_Chatbot/
├── assets/
│   ├── README.md
│   └── screenshots/
│       ├── home-page.png
│       └── chat-interface.png
├── faq.js                 # Local AI and ML FAQ knowledge base
├── index.html             # Main application page
├── LICENSE                # MIT License
├── README.md              # Project documentation
├── script.js              # Chat interface behaviour
├── style.css              # Responsive styles and animations
└── utils.js               # Text preprocessing and FAQ matching
~~~

## ⚙️ How It Works

1. The user enters an AI-related question.
2. The text is converted to lowercase, cleaned, tokenized, and stripped of common stopwords.
3. The chatbot compares the remaining words with locally stored FAQs.
4. The closest matching FAQ is selected using keyword similarity.
5. The corresponding answer appears in the chat.
6. If there is no suitable match, the chatbot displays a friendly suggestion message.

## 📸 Screenshots

### Home Page

![AI FAQ Chatbot home page](assets/screenshots/home-page.png)

### Chat Interface

![AI FAQ Chatbot conversation](assets/screenshots/chat-interface.png)

### Mobile View

> _Add a mobile screenshot here later: <code>assets/screenshots/mobile-view.png</code>_

## 💻 Installation

### Run locally

1. Clone the repository:

   ~~~bash
   git clone <YOUR_REPOSITORY_URL>
   ~~~

2. Open the project folder.
3. Double-click <code>index.html</code> to run the chatbot in a modern browser.

### Deploy online

- **Vercel:** Import the repository into Vercel and deploy it as a static site.

## 🔗 Live Demo

| Resource | Link |
| --- | --- |
| Live Demo | <code>&lt;Add Link&gt;</code> |

## 🔮 Future Improvements

- Voice input support
- More AI and Machine Learning FAQs
- Improved similarity matching
- Multiple FAQ categories
- Search history
- Multi-language support

## 🎓 Learning Outcomes

Building this project strengthened practical understanding of:

- Structuring a responsive frontend project
- Creating an interactive chatbot interface
- Applying basic NLP preprocessing in JavaScript
- Designing a simple FAQ similarity-matching workflow
- Preparing a project for GitHub and deployment platforms

## 👤 Author

Developed by **Asmit**

## 📄 License

This project is licensed under the [MIT License](LICENSE).
