/*
  Beginner-friendly text helpers used by the FAQ matcher.
  The chatbot does not call an API or send a user's question anywhere.
*/

const STOP_WORDS = new Set([
  "a", "an", "and", "are", "as", "at", "be", "by", "can", "do", "does",
  "for", "from", "how", "i", "in", "is", "it", "me", "my", "of", "on",
  "or", "please", "the", "to", "was", "what", "when", "where", "which",
  "who", "why", "will", "with", "would", "you", "your", "about", "tell",
  "explain", "give", "know", "learn", "mean", "more", "some", "that",
  "this", "want", "could", "should", "than", "then", "their", "they"
]);

/*
  Preprocessing steps:
  1. Convert to lowercase
  2. Remove punctuation
  3. Split the text into words (tokenize)
  4. Remove common words that do not add much meaning (stop words)
*/
function preprocessText(text) {
  const cleanText = text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  return cleanText
    .split(" ")
    .filter(function (word) {
      return word.length > 1 && !STOP_WORDS.has(word);
    });
}

function uniqueWords(words) {
  return [...new Set(words)];
}

/*
  Returns the FAQ with the greatest word overlap.
  Score = number of question keywords found in the FAQ / number of user keywords.
  This is intentionally simple so it is easy to explain in an internship interview.
*/
function findBestFAQ(userQuestion, faqList) {
  const normalizedQuestion = userQuestion
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  const userTokens = uniqueWords(preprocessText(userQuestion));

  if (!userTokens.length) {
    return null;
  }

  let bestMatch = null;
  let bestScore = 0;

  faqList.forEach(function (faq) {
    const normalizedFAQ = faq.question
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();

    // An exact question always wins.
    if (normalizedQuestion === normalizedFAQ) {
      bestMatch = { faq: faq, score: 1, exact: true };
      bestScore = 1;
      return;
    }

    const faqText = faq.question + " " + faq.keywords.join(" ");
    const faqTokens = new Set(preprocessText(faqText));
    let matchingWords = 0;

    userTokens.forEach(function (word) {
      if (faqTokens.has(word)) {
        matchingWords += 1;
      }
    });

    const score = matchingWords / userTokens.length;

    if (score > bestScore) {
      bestScore = score;
      bestMatch = { faq: faq, score: score, exact: false };
    }
  });

  // A match needs at least one meaningful shared word and a 34% overlap.
  if (!bestMatch || bestScore < 0.34) {
    return null;
  }

  return bestMatch;
}
