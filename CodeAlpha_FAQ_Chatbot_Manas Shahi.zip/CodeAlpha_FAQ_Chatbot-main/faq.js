/*
  Local FAQ knowledge base for NeuraBot.
  Every answer is stored in this file, so the chatbot works offline.
*/

const FAQ_DATA = [
  {
    question: "What is artificial intelligence?",
    answer: "Artificial Intelligence (AI) is a field of computer science that creates systems able to perform tasks that usually need human intelligence, such as learning, reasoning, recognizing images, and understanding language.",
    category: "AI Basics",
    keywords: ["artificial intelligence", "ai", "intelligent machines"]
  },
  {
    question: "What is machine learning?",
    answer: "Machine Learning (ML) is a part of AI where computers learn patterns from data instead of being given a separate rule for every situation.",
    category: "Machine Learning",
    keywords: ["machine learning", "ml", "learn from data"]
  },
  {
    question: "What is deep learning?",
    answer: "Deep Learning is a type of machine learning that uses neural networks with many layers. It is especially useful for images, speech, language, and other complex data.",
    category: "Deep Learning",
    keywords: ["deep learning", "many layers", "deep neural network"]
  },
  {
    question: "What is the difference between AI and machine learning?",
    answer: "AI is the broader goal of making machines act intelligently. Machine Learning is one approach to AI in which a system learns from examples and data.",
    category: "AI Basics",
    keywords: ["ai vs machine learning", "difference ai ml", "broader field"]
  },
  {
    question: "What is the difference between machine learning and deep learning?",
    answer: "Deep Learning is a subset of Machine Learning. Traditional ML can work with smaller data and hand-picked features, while deep learning usually needs more data and learns useful features through many neural-network layers.",
    category: "Deep Learning",
    keywords: ["machine learning vs deep learning", "ml dl difference", "subset"]
  },
  {
    question: "What is a neural network?",
    answer: "A neural network is a machine learning model made of connected layers of small units called neurons. The connections learn weights that help the model turn inputs into useful predictions.",
    category: "Neural Networks",
    keywords: ["neural network", "neurons", "weights", "layers"]
  },
  {
    question: "How do neural networks work?",
    answer: "Neural networks pass input data through layers of weighted connections. During training, the model compares its prediction with the correct answer and adjusts the weights to reduce mistakes.",
    category: "Neural Networks",
    keywords: ["how neural networks work", "network training", "adjust weights"]
  },
  {
    question: "What is supervised learning?",
    answer: "Supervised learning trains a model using labeled examples. Each example includes an input and the correct output, such as an email marked as spam or not spam.",
    category: "Machine Learning",
    keywords: ["supervised learning", "labeled data", "training labels"]
  },
  {
    question: "What is unsupervised learning?",
    answer: "Unsupervised learning finds patterns in unlabeled data. For example, it can group similar customers into clusters without being told the correct group beforehand.",
    category: "Machine Learning",
    keywords: ["unsupervised learning", "unlabeled data", "find patterns"]
  },
  {
    question: "What is reinforcement learning?",
    answer: "Reinforcement learning trains an agent through rewards and penalties. The agent takes actions, receives feedback from its environment, and learns a strategy that earns more reward over time.",
    category: "Machine Learning",
    keywords: ["reinforcement learning", "agent", "rewards", "environment"]
  },
  {
    question: "What is a dataset?",
    answer: "A dataset is an organized collection of data used for analysis or training a model. It may contain text, images, audio, numbers, labels, or other information.",
    category: "Data",
    keywords: ["dataset", "data collection", "training data"]
  },
  {
    question: "What is training data?",
    answer: "Training data is the part of a dataset used to teach a machine learning model. The model studies its patterns to learn how to make predictions.",
    category: "Data",
    keywords: ["training data", "train dataset", "teach model"]
  },
  {
    question: "What is validation data?",
    answer: "Validation data is used during model development to compare choices such as settings or model versions. It helps tune the model without using the final test data.",
    category: "Data",
    keywords: ["validation data", "validate model", "tuning data"]
  },
  {
    question: "What is test data?",
    answer: "Test data is a separate set of examples used only at the end to measure how well a trained model works on unseen data.",
    category: "Data",
    keywords: ["test data", "testing dataset", "unseen examples"]
  },
  {
    question: "What is a feature in machine learning?",
    answer: "A feature is an input variable used by a model. For a house-price model, features could include the number of rooms, location, and house area.",
    category: "Machine Learning",
    keywords: ["feature", "input variable", "model input"]
  },
  {
    question: "What is a label in machine learning?",
    answer: "A label is the correct answer a supervised model is trying to predict. For example, the label can be a house price or an email category.",
    category: "Machine Learning",
    keywords: ["label", "target variable", "correct output"]
  },
  {
    question: "What is a model in machine learning?",
    answer: "A machine learning model is a learned mathematical system that uses input data to make a prediction, classification, or decision.",
    category: "Machine Learning",
    keywords: ["machine learning model", "trained model", "prediction system"]
  },
  {
    question: "What is an algorithm in AI?",
    answer: "An algorithm is a step-by-step method for solving a problem. In AI, algorithms define how a system learns from data or makes decisions.",
    category: "AI Basics",
    keywords: ["algorithm", "ai algorithm", "step by step"]
  },
  {
    question: "What is classification?",
    answer: "Classification is a task where a model chooses a category. Examples include classifying a photo as a cat or dog, or an email as spam or not spam.",
    category: "Machine Learning",
    keywords: ["classification", "categories", "classify", "spam"]
  },
  {
    question: "What is regression in machine learning?",
    answer: "Regression is a task where a model predicts a number, such as a product price, temperature, sales amount, or travel time.",
    category: "Machine Learning",
    keywords: ["regression", "predict number", "continuous value"]
  },
  {
    question: "What is clustering?",
    answer: "Clustering is an unsupervised learning method that groups similar data points together. The groups are discovered from the data rather than supplied as labels.",
    category: "Machine Learning",
    keywords: ["clustering", "clusters", "group similar data"]
  },
  {
    question: "What is K-means clustering?",
    answer: "K-means is a clustering algorithm that divides data into K groups. It repeatedly assigns points to the nearest group center and updates each center.",
    category: "Machine Learning",
    keywords: ["k means", "kmeans", "cluster centers", "groups"]
  },
  {
    question: "What is overfitting?",
    answer: "Overfitting happens when a model memorizes training data too closely, including noise, and then performs poorly on new unseen data.",
    category: "Model Evaluation",
    keywords: ["overfitting", "memorize training data", "poor generalization"]
  },
  {
    question: "What is underfitting?",
    answer: "Underfitting happens when a model is too simple to learn the important patterns in the data. It performs poorly on both training data and new data.",
    category: "Model Evaluation",
    keywords: ["underfitting", "too simple", "poor training performance"]
  },
  {
    question: "What is bias in machine learning?",
    answer: "In model performance, bias is error caused by overly simple assumptions. In data ethics, bias can also mean unfair patterns in data or predictions. Both meanings should be checked carefully.",
    category: "Model Evaluation",
    keywords: ["bias", "model bias", "unfair predictions", "simple assumptions"]
  },
  {
    question: "What is variance in machine learning?",
    answer: "Variance describes how much a model's predictions change when it is trained on different data samples. Very high variance is often linked to overfitting.",
    category: "Model Evaluation",
    keywords: ["variance", "high variance", "prediction changes"]
  },
  {
    question: "What is the bias variance tradeoff?",
    answer: "The bias-variance tradeoff is the balance between a model being too simple and being too sensitive to training data. A good model aims to generalize well to new examples.",
    category: "Model Evaluation",
    keywords: ["bias variance tradeoff", "generalize", "balance"]
  },
  {
    question: "What is accuracy?",
    answer: "Accuracy is the percentage of predictions a model gets correct. It is useful when classes are balanced, but it can be misleading for highly imbalanced data.",
    category: "Model Evaluation",
    keywords: ["accuracy", "correct predictions", "evaluation metric"]
  },
  {
    question: "What is precision in machine learning?",
    answer: "Precision asks: of all items predicted as positive, how many were actually positive? It matters when false positive predictions are costly.",
    category: "Model Evaluation",
    keywords: ["precision", "false positives", "predicted positive"]
  },
  {
    question: "What is recall in machine learning?",
    answer: "Recall asks: of all truly positive items, how many did the model find? It matters when missing a positive case is costly.",
    category: "Model Evaluation",
    keywords: ["recall", "false negatives", "find positives"]
  },
  {
    question: "What is F1 score?",
    answer: "The F1 score combines precision and recall into one value. It is especially helpful when classes are imbalanced and both false positives and false negatives matter.",
    category: "Model Evaluation",
    keywords: ["f1 score", "precision recall", "imbalanced classes"]
  },
  {
    question: "What is a confusion matrix?",
    answer: "A confusion matrix is a table that compares actual classes with predicted classes. It shows true positives, true negatives, false positives, and false negatives.",
    category: "Model Evaluation",
    keywords: ["confusion matrix", "true positive", "false negative"]
  },
  {
    question: "What is cross validation?",
    answer: "Cross validation evaluates a model by splitting data into several parts and training and testing on different parts in turns. It gives a more reliable performance estimate on limited data.",
    category: "Model Evaluation",
    keywords: ["cross validation", "crossvalidation", "data folds"]
  },
  {
    question: "What is hyperparameter tuning?",
    answer: "Hyperparameter tuning is the process of choosing settings that control how a model learns, such as learning rate, tree depth, or the number of neighbors.",
    category: "Model Evaluation",
    keywords: ["hyperparameter tuning", "model settings", "learning rate"]
  },
  {
    question: "What is a loss function?",
    answer: "A loss function measures how far a model's prediction is from the correct answer. Training aims to reduce this value.",
    category: "Deep Learning",
    keywords: ["loss function", "prediction error", "reduce loss"]
  },
  {
    question: "What is gradient descent?",
    answer: "Gradient descent is an optimization method that repeatedly adjusts model parameters in the direction that reduces the loss function.",
    category: "Deep Learning",
    keywords: ["gradient descent", "optimization", "reduce loss", "parameters"]
  },
  {
    question: "What is a learning rate?",
    answer: "The learning rate controls the size of each update during training. A value that is too large can miss a good solution, while a value that is too small can make training very slow.",
    category: "Deep Learning",
    keywords: ["learning rate", "training step size", "model update"]
  },
  {
    question: "What is an epoch?",
    answer: "An epoch is one complete pass of the training algorithm through the entire training dataset.",
    category: "Deep Learning",
    keywords: ["epoch", "complete pass", "training dataset"]
  },
  {
    question: "What is a batch in machine learning?",
    answer: "A batch is a smaller group of training examples processed together before the model updates its parameters.",
    category: "Deep Learning",
    keywords: ["batch", "batch size", "training examples"]
  },
  {
    question: "What is an activation function?",
    answer: "An activation function adds non-linearity to a neural network. It helps the network learn complex relationships instead of only simple straight-line patterns.",
    category: "Neural Networks",
    keywords: ["activation function", "non linear", "relu", "sigmoid"]
  },
  {
    question: "What is ReLU?",
    answer: "ReLU, or Rectified Linear Unit, is a popular activation function that outputs zero for negative values and keeps positive values unchanged.",
    category: "Neural Networks",
    keywords: ["relu", "rectified linear unit", "activation"]
  },
  {
    question: "What is backpropagation?",
    answer: "Backpropagation is the process neural networks use to calculate how each weight contributed to an error. That information is then used to update the weights during training.",
    category: "Neural Networks",
    keywords: ["backpropagation", "back propagation", "update weights", "network error"]
  },
  {
    question: "What is natural language processing?",
    answer: "Natural Language Processing (NLP) is an AI field that helps computers work with human language. It includes tasks such as translation, sentiment analysis, chatbots, and text summarization.",
    category: "Language AI",
    keywords: ["natural language processing", "nlp", "human language", "text"]
  },
  {
    question: "What is tokenization in NLP?",
    answer: "Tokenization is the process of splitting text into smaller pieces called tokens, such as words, subwords, or characters, so a computer can process the text.",
    category: "Language AI",
    keywords: ["tokenization", "tokens", "split text", "nlp"]
  },
  {
    question: "What are stop words?",
    answer: "Stop words are common words such as 'the', 'is', and 'and' that are often removed in simple text processing because they usually add little meaning for matching.",
    category: "Language AI",
    keywords: ["stop words", "common words", "text preprocessing"]
  },
  {
    question: "What is sentiment analysis?",
    answer: "Sentiment analysis uses NLP to identify the opinion or emotion in text, such as positive, negative, or neutral customer feedback.",
    category: "Language AI",
    keywords: ["sentiment analysis", "emotion", "positive negative", "opinion"]
  },
  {
    question: "What is text classification?",
    answer: "Text classification automatically assigns categories to text. Examples include spam detection, topic labeling, and sentiment analysis.",
    category: "Language AI",
    keywords: ["text classification", "classify text", "spam detection"]
  },
  {
    question: "What is named entity recognition?",
    answer: "Named Entity Recognition, often called NER, identifies real-world names in text, such as people, locations, organizations, dates, and products.",
    category: "Language AI",
    keywords: ["named entity recognition", "ner", "people locations organizations"]
  },
  {
    question: "What is machine translation?",
    answer: "Machine translation uses AI to translate text or speech from one language to another, such as translating English into Hindi.",
    category: "Language AI",
    keywords: ["machine translation", "translate languages", "language translation"]
  },
  {
    question: "What is a chatbot?",
    answer: "A chatbot is a program that communicates with people through text or voice. It can use fixed rules, FAQ matching, or more advanced language models.",
    category: "Language AI",
    keywords: ["chatbot", "conversational bot", "text conversation"]
  },
  {
    question: "What is a large language model?",
    answer: "A Large Language Model, or LLM, is a neural network trained on a very large amount of text to understand and generate human-like language.",
    category: "Language AI",
    keywords: ["large language model", "llm", "language model", "generate text"]
  },
  {
    question: "What is generative AI?",
    answer: "Generative AI is AI that creates new content such as text, images, audio, video, or code based on patterns learned from training data.",
    category: "Generative AI",
    keywords: ["generative ai", "generate content", "create text images"]
  },
  {
    question: "What is prompt engineering?",
    answer: "Prompt engineering is the practice of writing clear instructions and context for an AI system so it can produce more useful and accurate results.",
    category: "Generative AI",
    keywords: ["prompt engineering", "write prompts", "ai instructions"]
  },
  {
    question: "What is computer vision?",
    answer: "Computer vision is an AI field that enables computers to understand images and videos. Common tasks include object detection, face recognition, and image classification.",
    category: "Computer Vision",
    keywords: ["computer vision", "images videos", "visual ai"]
  },
  {
    question: "What is image classification?",
    answer: "Image classification is a computer vision task where a model assigns a label to an image, such as identifying whether it contains a plant, car, or animal.",
    category: "Computer Vision",
    keywords: ["image classification", "classify image", "picture labels"]
  },
  {
    question: "What is object detection?",
    answer: "Object detection identifies objects in an image and marks where they appear, usually with bounding boxes and class labels.",
    category: "Computer Vision",
    keywords: ["object detection", "bounding boxes", "detect objects"]
  },
  {
    question: "What is image segmentation?",
    answer: "Image segmentation divides an image into meaningful regions or pixels, such as separating a person from the background or marking roads in a street image.",
    category: "Computer Vision",
    keywords: ["image segmentation", "pixels", "image regions"]
  },
  {
    question: "What is facial recognition?",
    answer: "Facial recognition is computer vision technology that detects a face and may compare it with known faces to identify or verify a person. It must be used carefully because of privacy and fairness concerns.",
    category: "Computer Vision",
    keywords: ["facial recognition", "face recognition", "identify face", "privacy"]
  },
  {
    question: "What is a convolutional neural network?",
    answer: "A Convolutional Neural Network, or CNN, is a neural network designed especially for image data. It uses convolution layers to learn visual patterns such as edges, textures, and shapes.",
    category: "Computer Vision",
    keywords: ["convolutional neural network", "cnn", "convolution", "image network"]
  },
  {
    question: "What is a recurrent neural network?",
    answer: "A Recurrent Neural Network, or RNN, is a neural network designed for sequence data such as text, speech, or time series. It uses information from earlier sequence steps when processing later ones.",
    category: "Neural Networks",
    keywords: ["recurrent neural network", "rnn", "sequence data", "time series"]
  },
  {
    question: "What is a transformer model?",
    answer: "A transformer is a neural-network architecture that uses attention to relate important parts of a sequence. It is widely used in modern language and generative AI systems.",
    category: "Generative AI",
    keywords: ["transformer", "attention", "language architecture", "modern llm"]
  },
  {
    question: "What is attention in AI?",
    answer: "Attention is a mechanism that helps a model focus on the most relevant parts of its input when making a prediction or generating output.",
    category: "Generative AI",
    keywords: ["attention", "focus input", "transformer attention"]
  },
  {
    question: "What is speech recognition?",
    answer: "Speech recognition converts spoken language into written text. It is used in voice assistants, captions, dictation, and call-center tools.",
    category: "Language AI",
    keywords: ["speech recognition", "voice to text", "spoken language"]
  },
  {
    question: "What is text to speech?",
    answer: "Text-to-speech, or TTS, converts written text into artificial spoken audio. It is used in voice assistants, accessibility tools, and navigation systems.",
    category: "Language AI",
    keywords: ["text to speech", "tts", "text audio", "voice generation"]
  },
  {
    question: "What is data preprocessing?",
    answer: "Data preprocessing prepares raw data for machine learning. Common steps include cleaning errors, handling missing values, formatting data, scaling numbers, and encoding categories.",
    category: "Data",
    keywords: ["data preprocessing", "clean data", "prepare data", "missing values"]
  },
  {
    question: "What is data cleaning?",
    answer: "Data cleaning improves data quality by fixing errors, removing duplicates, handling missing values, and making formats consistent.",
    category: "Data",
    keywords: ["data cleaning", "clean dataset", "duplicates", "data errors"]
  },
  {
    question: "What is normalization in machine learning?",
    answer: "Normalization rescales numeric values to a common range, often between zero and one. It can help some models train more effectively when features have very different scales.",
    category: "Data",
    keywords: ["normalization", "scale values", "feature scaling", "zero one"]
  },
  {
    question: "What is standardization in machine learning?",
    answer: "Standardization rescales a numeric feature so it has a mean near zero and a standard deviation near one. It is another common feature-scaling method.",
    category: "Data",
    keywords: ["standardization", "mean zero", "standard deviation", "scaling"]
  },
  {
    question: "What is one hot encoding?",
    answer: "One-hot encoding changes a category into separate yes-or-no columns. For example, colors red, blue, and green can become three columns with zeros and ones.",
    category: "Data",
    keywords: ["one hot encoding", "onehot", "categorical data", "zero one"]
  },
  {
    question: "What is feature engineering?",
    answer: "Feature engineering creates, transforms, or selects input features so a model can learn a problem more effectively. It often uses domain knowledge.",
    category: "Data",
    keywords: ["feature engineering", "create features", "select features"]
  },
  {
    question: "What is dimensionality reduction?",
    answer: "Dimensionality reduction reduces the number of features while keeping as much useful information as possible. It can simplify data, reduce noise, and make visualization easier.",
    category: "Data",
    keywords: ["dimensionality reduction", "reduce features", "fewer dimensions"]
  },
  {
    question: "What is PCA?",
    answer: "PCA, or Principal Component Analysis, is a dimensionality-reduction method that creates new features called principal components to capture as much variation in the data as possible.",
    category: "Data",
    keywords: ["pca", "principal component analysis", "reduce dimensions"]
  },
  {
    question: "What is a decision tree?",
    answer: "A decision tree is a model that makes decisions by asking a series of questions about features. It is easy to visualize and can be used for classification or regression.",
    category: "Machine Learning",
    keywords: ["decision tree", "tree model", "feature questions"]
  },
  {
    question: "What is a random forest?",
    answer: "A random forest combines many decision trees. Their combined predictions are usually more stable and accurate than a single tree.",
    category: "Machine Learning",
    keywords: ["random forest", "many decision trees", "ensemble"]
  },
  {
    question: "What is support vector machine?",
    answer: "A Support Vector Machine, or SVM, is a model that tries to find a boundary that separates classes with the largest possible margin.",
    category: "Machine Learning",
    keywords: ["support vector machine", "svm", "separating boundary", "margin"]
  },
  {
    question: "What is K nearest neighbors?",
    answer: "K-Nearest Neighbors, or KNN, predicts based on the most similar nearby examples in the training data. The value K is the number of neighbors considered.",
    category: "Machine Learning",
    keywords: ["k nearest neighbors", "knn", "nearby examples", "neighbors"]
  },
  {
    question: "What is logistic regression?",
    answer: "Logistic regression is a classification algorithm that estimates the probability of a class, often for problems with two possible outcomes such as yes or no.",
    category: "Machine Learning",
    keywords: ["logistic regression", "classification probability", "binary outcome"]
  },
  {
    question: "What is linear regression?",
    answer: "Linear regression predicts a numeric value by fitting a straight-line relationship between input features and the target value.",
    category: "Machine Learning",
    keywords: ["linear regression", "straight line", "numeric prediction"]
  },
  {
    question: "What is ensemble learning?",
    answer: "Ensemble learning combines predictions from multiple models to improve accuracy or stability. Random forests are a common example.",
    category: "Machine Learning",
    keywords: ["ensemble learning", "combine models", "multiple models"]
  },
  {
    question: "What is model deployment?",
    answer: "Model deployment means making a trained model available for use in an application or workflow so it can receive new input and return predictions.",
    category: "AI Projects",
    keywords: ["model deployment", "deploy model", "use predictions"]
  },
  {
    question: "What is inference in machine learning?",
    answer: "Inference is the stage where a trained model receives new data and produces a prediction, classification, or other output.",
    category: "AI Projects",
    keywords: ["inference", "model prediction", "new data"]
  },
  {
    question: "What is explainable AI?",
    answer: "Explainable AI, or XAI, focuses on making model decisions easier for people to understand and trust, especially in important areas such as healthcare and finance.",
    category: "AI Ethics",
    keywords: ["explainable ai", "xai", "understand decisions", "trust"]
  },
  {
    question: "What is AI ethics?",
    answer: "AI ethics is the study and practice of building and using AI responsibly. It includes fairness, privacy, safety, transparency, accountability, and avoiding harm.",
    category: "AI Ethics",
    keywords: ["ai ethics", "responsible ai", "fairness privacy safety"]
  },
  {
    question: "What is algorithmic bias?",
    answer: "Algorithmic bias happens when an AI system produces unfair or systematically different outcomes for certain people or groups, often because of biased data or design choices.",
    category: "AI Ethics",
    keywords: ["algorithmic bias", "unfair ai", "biased data", "fairness"]
  },
  {
    question: "Why is data privacy important in AI?",
    answer: "AI systems can use sensitive data, so privacy is important to protect people, follow laws, reduce misuse, and build trust. Data should be collected and used only when there is a clear, appropriate reason.",
    category: "AI Ethics",
    keywords: ["data privacy", "privacy ai", "sensitive data", "protect people"]
  },
  {
    question: "What is responsible AI?",
    answer: "Responsible AI means designing, testing, deploying, and monitoring AI systems in ways that are fair, safe, transparent, private, and accountable.",
    category: "AI Ethics",
    keywords: ["responsible ai", "safe fair transparent", "accountable"]
  },
  {
    question: "What is robotics?",
    answer: "Robotics is the field of designing and operating robots. AI can help robots perceive their surroundings, plan actions, learn from data, and interact more naturally.",
    category: "Robotics",
    keywords: ["robotics", "robots", "ai robots", "robot actions"]
  },
  {
    question: "What is autonomous driving?",
    answer: "Autonomous driving uses sensors, computer vision, maps, and AI to help a vehicle understand its environment and make driving decisions. Safety testing and human oversight are critical.",
    category: "Robotics",
    keywords: ["autonomous driving", "self driving car", "vehicle ai", "sensors"]
  },
  {
    question: "What is an AI agent?",
    answer: "An AI agent is a system that observes an environment, makes decisions, and takes actions to reach a goal. A reinforcement-learning agent is one example.",
    category: "AI Basics",
    keywords: ["ai agent", "intelligent agent", "actions goals", "environment"]
  },
  {
    question: "What is the Turing test?",
    answer: "The Turing Test is a classic idea proposed by Alan Turing. It asks whether a machine can communicate in a way that makes a human judge unable to reliably tell it apart from a person.",
    category: "AI History",
    keywords: ["turing test", "alan turing", "machine intelligence"]
  },
  {
    question: "Who is known as the father of AI?",
    answer: "John McCarthy is often called the father of AI because he helped organize the 1956 Dartmouth workshop and coined the term 'Artificial Intelligence'.",
    category: "AI History",
    keywords: ["father of ai", "john mccarthy", "ai history"]
  },
  {
    question: "What is the AI winter?",
    answer: "AI winter refers to periods when interest, funding, and expectations for AI dropped because earlier systems did not meet ambitious promises.",
    category: "AI History",
    keywords: ["ai winter", "ai funding", "ai history"]
  },
  {
    question: "What programming language is popular for AI?",
    answer: "Python is widely used for AI because it is readable and has a large ecosystem of data and machine learning tools. Other languages can also be useful depending on the project.",
    category: "AI Projects",
    keywords: ["programming language ai", "python ai", "language machine learning"]
  },
  {
    question: "How can I start learning AI?",
    answer: "Start with Python basics, simple statistics, and core machine learning ideas such as datasets, features, training, and evaluation. Then build small projects like a FAQ bot, image classifier, or prediction model.",
    category: "AI Learning",
    keywords: ["start learning ai", "learn artificial intelligence", "ai beginner", "study ai"]
  },
  {
    question: "Do I need mathematics for AI?",
    answer: "Basic mathematics is helpful for understanding AI, especially algebra, probability, statistics, and later calculus. You can still begin practical projects first and learn the math gradually.",
    category: "AI Learning",
    keywords: ["math for ai", "mathematics machine learning", "algebra statistics"]
  },
  {
    question: "What projects can a beginner make with AI?",
    answer: "Beginner-friendly AI projects include an FAQ chatbot, spam classifier, movie recommender, sentiment analyzer, simple image classifier, or house-price predictor.",
    category: "AI Learning",
    keywords: ["beginner ai projects", "ai project ideas", "machine learning projects"]
  },
  {
    question: "What is a recommendation system?",
    answer: "A recommendation system suggests useful items to users, such as movies, products, songs, or courses. It can use user behavior, item similarity, or both.",
    category: "AI Applications",
    keywords: ["recommendation system", "recommender", "suggest movies products"]
  },
  {
    question: "How is AI used in healthcare?",
    answer: "AI can support healthcare by analyzing medical images, helping with documentation, predicting risks, and assisting research. It should be carefully tested and used with qualified human oversight.",
    category: "AI Applications",
    keywords: ["ai healthcare", "medical ai", "health applications"]
  },
  {
    question: "How is AI used in education?",
    answer: "AI can support education through personalized practice, tutoring tools, accessibility features, feedback, and learning analytics. Good use should protect student privacy and support teachers.",
    category: "AI Applications",
    keywords: ["ai education", "learning tools", "personalized education"]
  },
  {
    question: "How is AI used in cybersecurity?",
    answer: "AI can help cybersecurity teams detect unusual behavior, identify spam or malware patterns, prioritize alerts, and respond faster. It should be combined with strong security practices and human review.",
    category: "AI Applications",
    keywords: ["ai cybersecurity", "security ai", "detect malware", "unusual behavior"]
  }
];
